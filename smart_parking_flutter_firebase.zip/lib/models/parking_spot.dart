class ParkingSpot {
  final int id;
  final String location;
  final bool isAvailable;
  final double pricePerHour;

  ParkingSpot({
    required this.id,
    required this.location,
    required this.isAvailable,
    required this.pricePerHour,
  });

  factory ParkingSpot.fromJson(Map<String, dynamic> json) => ParkingSpot(
    id: json['id'],
    location: json['location'],
    isAvailable: json['isAvailable'],
    pricePerHour: json['pricePerHour'].toDouble(),
  );

  Map<String, dynamic> toJson() => {
    'location': location,
    'isAvailable': isAvailable,
    'pricePerHour': pricePerHour,
  };
}
