import 'package:flutter/material.dart';
import 'package:flutter_bloc/flutter_bloc.dart';
import 'package:firebase_core/firebase_core.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:dio/dio.dart';
import 'cubit/spot_cubit.dart';
import 'cubit/auth_cubit.dart';
import 'models/parking_spot.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Firebase.initializeApp();
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  final Dio dio = Dio(BaseOptions(baseUrl: 'http://localhost:8080'));

  @override
  Widget build(BuildContext context) {
    return MultiBlocProvider(
      providers: [
        BlocProvider(create: (_) => AuthCubit()),
        BlocProvider(create: (_) => SpotCubit(dio)),
      ],
      child: MaterialApp(
        title: 'Smart Parking App',
        home: AuthGate(),
      ),
    );
  }
}

class AuthGate extends StatelessWidget {
  final emailCtrl = TextEditingController();
  final passCtrl = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Login")),
      body: BlocBuilder<AuthCubit, AuthState>(
        builder: (context, state) {
          if (state is AuthLoading) return Center(child: CircularProgressIndicator());
          if (state is AuthAuthenticated) {
            context.read<SpotCubit>().fetchSpots();
            return HomeScreen();
          }
          if (state is AuthError) return Center(child: Text(state.message));
          return Padding(
            padding: EdgeInsets.all(16),
            child: Column(children: [
              TextField(controller: emailCtrl, decoration: InputDecoration(labelText: "Email")),
              TextField(controller: passCtrl, decoration: InputDecoration(labelText: "Password"), obscureText: true),
              ElevatedButton(
                onPressed: () => context.read<AuthCubit>().signIn(emailCtrl.text, passCtrl.text),
                child: Text("Login"),
              ),
            ]),
          );
        },
      ),
    );
  }
}

class HomeScreen extends StatelessWidget {
  final _locationController = TextEditingController();
  final _priceController = TextEditingController();
  final _availability = ValueNotifier<bool>(true);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Parking Spots"),
        actions: [IconButton(onPressed: () => context.read<AuthCubit>().signOut(), icon: Icon(Icons.logout))],
      ),
      body: Column(
        children: [
          Expanded(child: BlocBuilder<SpotCubit, SpotState>(
            builder: (context, state) {
              if (state is SpotLoading) return Center(child: CircularProgressIndicator());
              if (state is SpotError) return Center(child: Text(state.message));
              if (state is SpotLoaded) {
                return ListView.builder(
                  itemCount: state.spots.length,
                  itemBuilder: (context, index) {
                    final spot = state.spots[index];
                    return ListTile(
                      title: Text(spot.location),
                      subtitle: Text("€${spot.pricePerHour}/h - Available: ${spot.isAvailable}"),
                    );
                  },
                );
              }
              return Center(child: Text("No data"));
            },
          )),
          Padding(
            padding: EdgeInsets.all(8),
            child: Column(
              children: [
                TextField(controller: _locationController, decoration: InputDecoration(labelText: "Location")),
                TextField(controller: _priceController, keyboardType: TextInputType.number, decoration: InputDecoration(labelText: "Price/hour")),
                Row(
                  children: [
                    Text("Available"),
                    ValueListenableBuilder<bool>(
                      valueListenable: _availability,
                      builder: (_, val, __) => Switch(value: val, onChanged: (v) => _availability.value = v),
                    ),
                  ],
                ),
                ElevatedButton(
                  child: Text("Add Spot"),
                  onPressed: () {
                    final spot = ParkingSpot(
                      id: 0,
                      location: _locationController.text,
                      isAvailable: _availability.value,
                      pricePerHour: double.tryParse(_priceController.text) ?? 0,
                    );
                    context.read<SpotCubit>().addSpot(spot);
                  },
                ),
              ],
            ),
          )
        ],
      ),
    );
  }
}
