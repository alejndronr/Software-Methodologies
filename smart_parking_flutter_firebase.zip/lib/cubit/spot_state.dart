part of 'spot_cubit.dart';

abstract class SpotState extends Equatable {
  const SpotState();
  @override
  List<Object> get props => [];
}

class SpotInitial extends SpotState {}
class SpotLoading extends SpotState {}
class SpotLoaded extends SpotState {
  final List<ParkingSpot> spots;
  const SpotLoaded(this.spots);
  @override
  List<Object> get props => [spots];
}
class SpotError extends SpotState {
  final String message;
  const SpotError(this.message);
  @override
  List<Object> get props => [message];
}
