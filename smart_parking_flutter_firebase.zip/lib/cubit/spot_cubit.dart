import 'package:bloc/bloc.dart';
import 'package:dio/dio.dart';
import '../models/parking_spot.dart';
import 'package:equatable/equatable.dart';

part 'spot_state.dart';

class SpotCubit extends Cubit<SpotState> {
  final Dio dio;

  SpotCubit(this.dio) : super(SpotInitial());

  Future<void> fetchSpots() async {
    emit(SpotLoading());
    try {
      final res = await dio.get('/spots');
      final List spots = res.data;
      emit(SpotLoaded(spots.map((e) => ParkingSpot.fromJson(e)).toList()));
    } catch (_) {
      emit(SpotError("Failed to load spots"));
    }
  }

  Future<void> addSpot(ParkingSpot spot) async {
    try {
      await dio.post('/spots', data: spot.toJson());
      fetchSpots();
    } catch (_) {
      emit(SpotError("Failed to add spot"));
    }
  }
}
